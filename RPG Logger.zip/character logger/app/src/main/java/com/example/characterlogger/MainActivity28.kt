package com.example.characterlogger

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.CountDownTimer
import android.widget.TextView
import kotlinx.android.synthetic.main.activity_main24.*
import kotlinx.android.synthetic.main.activity_main26.*
import kotlinx.android.synthetic.main.activity_main26.T1
import kotlinx.android.synthetic.main.activity_main26.T2
import kotlinx.android.synthetic.main.activity_main26.dcTitles3
import kotlinx.android.synthetic.main.activity_main28.*
import java.lang.String
import kotlinx.android.synthetic.main.activity_main24.dcTitles4 as dcTitles41
import kotlinx.android.synthetic.main.activity_main26.dcTitles4 as dcTitles41
/*
code for the fourth dungeon champaign maker
 */
class MainActivity28 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main28)
/*
variables for inputs
 */
        val Title1 = intent.getStringExtra("T1")
        val Title1TextView: TextView = findViewById(R.id.cTitles1)
        Title1TextView.text = Title1

        val S1 = intent.getStringExtra("R1")
        val S1TextView: TextView = findViewById(R.id.S1)
        S1TextView.text = S1

        val Title2 = intent.getStringExtra("T2")
        val Title2TextView: TextView = findViewById(R.id.cTitles2)
        Title2TextView.text = Title2

        val S2 = intent.getStringExtra("R2")
        val S2TextView: TextView = findViewById(R.id.S2)
        S2TextView.text = S2

        val Title3 = intent.getStringExtra("T3")
        val Title3TextView: TextView = findViewById(R.id.cTitles3)
        Title3TextView.text = Title3

        val S3 = intent.getStringExtra("R3")
        val S3TextView: TextView = findViewById(R.id.S3)
        S3TextView.text = S3

        val Title4 = intent.getStringExtra("T4")
        val Title4TextView: TextView = findViewById(R.id.cTitles4)
        Title4TextView.text = Title4

        val S4 = intent.getStringExtra("R4")
        val S4TextView: TextView = findViewById(R.id.S4)
        S4TextView.text = S4

        val Title5 = intent.getStringExtra("T5")
        val Title5TextView: TextView = findViewById(R.id.cTitles5)
        Title5TextView.text = Title5

        val S5 = intent.getStringExtra("R5")
        val S5TextView: TextView = findViewById(R.id.S5)
        S5TextView.text = S5

        val Time1 = intent.getStringExtra("TI1")
        val Time1TextView: TextView = findViewById(R.id.T1)
        Time1TextView.text = Time1

        val Time2 = intent.getStringExtra("TI2")
        val Time2TextView: TextView = findViewById(R.id.T2)
        Time2TextView.text = Time2

        val DTitle1 = intent.getStringExtra("DT1")
        val DTitle1TextView: TextView = findViewById(R.id.dcTitles1)
        DTitle1TextView.text = DTitle1

        val DS1 = intent.getStringExtra("DR1")
        val DS1TextView: TextView = findViewById(R.id.DS1)
        DS1TextView.text = DS1

        val DTitle2 = intent.getStringExtra("DT2")
        val DTitle2TextView: TextView = findViewById(R.id.dcTitles2)
        DTitle2TextView.text = DTitle2

        val DS2 = intent.getStringExtra("DR2")
        val DS2TextView: TextView = findViewById(R.id.DS2)
        DS2TextView.text = DS2

        val DTitle3 = intent.getStringExtra("DT3")
        val DTitle3TextView: TextView = findViewById(R.id.dcTitles3)
        DTitle3TextView.text = DTitle3

        val DS3 = intent.getStringExtra("DR3")
        val DS3TextView: TextView = findViewById(R.id.DS3)
        DS3TextView.text = DS3

        val DTitle5 = intent.getStringExtra("DT5")
        val DTitle5TextView: TextView = findViewById(R.id.dcTitles5)
        DTitle5TextView.text = DTitle5

        val DS5 = intent.getStringExtra("DR5")
        val DS5TextView: TextView = findViewById(R.id.DS5)
        DS5TextView.text = DS5

        val Name1 = intent.getStringExtra("CN1")
        val Name1TextView: TextView = findViewById(R.id.Name1)
        Name1TextView.text = Name1

        val Class1 = intent.getStringExtra("CC1")
        val Class1TextView: TextView = findViewById(R.id.Class1)
        Class1TextView.text = Class1

        val Race1 = intent.getStringExtra("CR1")
        val Race1TextView: TextView = findViewById(R.id.Race1)
        Race1TextView.text = Race1

        val SMod1 = intent.getStringExtra("CSM1")
        val SMod1TextView: TextView = findViewById(R.id.SMod1)
        SMod1TextView.text = SMod1

        val DMod1 = intent.getStringExtra("CDM1")
        val DMod1TextView: TextView = findViewById(R.id.DMod1)
        DMod1TextView.text = DMod1

        val CNMod1 = intent.getStringExtra("CCNM1")
        val CNMod1TextView: TextView = findViewById(R.id.CNMod1)
        CNMod1TextView.text = CNMod1

        val IMod1 = intent.getStringExtra("CIM1")
        val IMod1TextView: TextView = findViewById(R.id.IMod1)
        IMod1TextView.text = IMod1

        val WMod1 = intent.getStringExtra("CWM1")
        val WMod1TextView: TextView = findViewById(R.id.WMod1)
        WMod1TextView.text = WMod1

        val CMMod1 = intent.getStringExtra("CCMM1")
        val CMMod1TextView: TextView = findViewById(R.id.CMMod1)
        CMMod1TextView.text = CMMod1

        val Strength1 = intent.getStringExtra("CS1")
        val Strength1TextView: TextView = findViewById(R.id.Strength1)
        Strength1TextView.text = Strength1

        val Dexerity1 = intent.getStringExtra("CD1")
        val Dexerity1TextView: TextView = findViewById(R.id.Dexerity1)
        Dexerity1TextView.text = Dexerity1

        val Constitution1 = intent.getStringExtra("CCN1")
        val Constitution1TextView: TextView = findViewById(R.id.Constitution1)
        Constitution1TextView.text = Constitution1

        val Intelligence1 = intent.getStringExtra("CI1")
        val Intelligence1TextView: TextView = findViewById(R.id.Intelligence1)
        Intelligence1TextView.text = Intelligence1

        val Wisdom1 = intent.getStringExtra("CW1")
        val Wisdom1TextView: TextView = findViewById(R.id.Wisdom1)
        Wisdom1TextView.text = Wisdom1

        val Charisma1 = intent.getStringExtra("CCM1")
        val Charisma1TextView: TextView = findViewById(R.id.Charisma1)
        Charisma1TextView.text = Charisma1

        val B1 = intent.getStringExtra("CB1")
        val B1TextView: TextView = findViewById(R.id.B1)
        B1TextView.text = B1

        val A1 = intent.getStringExtra("CA1")
        val A1TextView: TextView = findViewById(R.id.A1)
        A1TextView.text = A1

        val HP1 = intent.getStringExtra("CHP1")
        val HP1TextView: TextView = findViewById(R.id.HP1)
        HP1TextView.text = HP1

        val Name2 = intent.getStringExtra("CN2")
        val Name2TextView: TextView = findViewById(R.id.Name2)
        Name2TextView.text = Name2

        val Class2 = intent.getStringExtra("CC2")
        val Class2TextView: TextView = findViewById(R.id.Class2)
        Class2TextView.text = Class2

        val Race2 = intent.getStringExtra("CR2")
        val Race2TextView: TextView = findViewById(R.id.Race2)
        Race2TextView.text = Race2

        val SMod2 = intent.getStringExtra("CSM2")
        val SMod2TextView: TextView = findViewById(R.id.SMod2)
        SMod2TextView.text = SMod2

        val DMod2 = intent.getStringExtra("CDM2")
        val DMod2TextView: TextView = findViewById(R.id.DMod2)
        DMod2TextView.text = DMod2

        val CNMod2 = intent.getStringExtra("CCNM2")
        val CNMod2TextView: TextView = findViewById(R.id.CNMod2)
        CNMod2TextView.text = CNMod2

        val IMod2 = intent.getStringExtra("CIM2")
        val IMod2TextView: TextView = findViewById(R.id.IMod2)
        IMod2TextView.text = IMod2

        val WMod2 = intent.getStringExtra("CWM2")
        val WMod2TextView: TextView = findViewById(R.id.WMod2)
        WMod2TextView.text = WMod2

        val CMMod2 = intent.getStringExtra("CCMM2")
        val CMMod2TextView: TextView = findViewById(R.id.CMMod2)
        CMMod2TextView.text = CMMod2

        val Strength2 = intent.getStringExtra("CS2")
        val Strength2TextView: TextView = findViewById(R.id.Strength2)
        Strength2TextView.text = Strength2

        val Dexerity2 = intent.getStringExtra("CD2")
        val Dexerity2TextView: TextView = findViewById(R.id.Dexerity2)
        Dexerity2TextView.text = Dexerity2

        val Constitution2 = intent.getStringExtra("CCN2")
        val Constitution2TextView: TextView = findViewById(R.id.Constitution2)
        Constitution2TextView.text = Constitution2

        val Intelligence2 = intent.getStringExtra("CI2")
        val Intelligence2TextView: TextView = findViewById(R.id.Intelligence2)
        Intelligence2TextView.text = Intelligence2

        val Wisdom2 = intent.getStringExtra("CW2")
        val Wisdom2TextView: TextView = findViewById(R.id.Wisdom2)
        Wisdom2TextView.text = Wisdom2

        val Charisma2 = intent.getStringExtra("CCM2")
        val Charisma2TextView: TextView = findViewById(R.id.Charisma2)
        Charisma2TextView.text = Charisma2

        val B2 = intent.getStringExtra("CB2")
        val B2TextView: TextView = findViewById(R.id.B2)
        B2TextView.text = B2

        val A2 = intent.getStringExtra("CA2")
        val A2TextView: TextView = findViewById(R.id.A2)
        A2TextView.text = A2

        val HP2 = intent.getStringExtra("CHP2")
        val HP2TextView: TextView = findViewById(R.id.HP2)
        HP2TextView.text = HP2

        val Name3 = intent.getStringExtra("CN3")
        val Name3TextView: TextView = findViewById(R.id.Name3)
        Name3TextView.text = Name3

        val Class3 = intent.getStringExtra("CC3")
        val Class3TextView: TextView = findViewById(R.id.Class3)
        Class3TextView.text = Class3

        val Race3 = intent.getStringExtra("CR3")
        val Race3TextView: TextView = findViewById(R.id.Race3)
        Race3TextView.text = Race3

        val SMod3 = intent.getStringExtra("CSM3")
        val SMod3TextView: TextView = findViewById(R.id.SMod3)
        SMod3TextView.text = SMod3

        val DMod3 = intent.getStringExtra("CDM3")
        val DMod3TextView: TextView = findViewById(R.id.DMod3)
        DMod3TextView.text = DMod3

        val CNMod3 = intent.getStringExtra("CCNM3")
        val CNMod3TextView: TextView = findViewById(R.id.CNMod3)
        CNMod3TextView.text = CNMod3

        val IMod3 = intent.getStringExtra("CIM3")
        val IMod3TextView: TextView = findViewById(R.id.IMod3)
        IMod3TextView.text = IMod3

        val WMod3 = intent.getStringExtra("CWM3")
        val WMod3TextView: TextView = findViewById(R.id.WMod3)
        WMod3TextView.text = WMod3

        val CMMod3 = intent.getStringExtra("CCMM3")
        val CMMod3TextView: TextView = findViewById(R.id.CMMod3)
        CMMod3TextView.text = CMMod3

        val Strength3 = intent.getStringExtra("CS3")
        val Strength3TextView: TextView = findViewById(R.id.Strength3)
        Strength3TextView.text = Strength3

        val Dexerity3 = intent.getStringExtra("CD3")
        val Dexerity3TextView: TextView = findViewById(R.id.Dexerity3)
        Dexerity3TextView.text = Dexerity3

        val Constitution3 = intent.getStringExtra("CCN3")
        val Constitution3TextView: TextView = findViewById(R.id.Constitution3)
        Constitution3TextView.text = Constitution3

        val Intelligence3 = intent.getStringExtra("CI3")
        val Intelligence3TextView: TextView = findViewById(R.id.Intelligence3)
        Intelligence3TextView.text = Intelligence3

        val Wisdom3 = intent.getStringExtra("CW3")
        val Wisdom3TextView: TextView = findViewById(R.id.Wisdom3)
        Wisdom3TextView.text = Wisdom3

        val Charisma3 = intent.getStringExtra("CCM3")
        val Charisma3TextView: TextView = findViewById(R.id.Charisma3)
        Charisma3TextView.text = Charisma3

        val B3 = intent.getStringExtra("CB3")
        val B3TextView: TextView = findViewById(R.id.B3)
        B3TextView.text = B3

        val A3 = intent.getStringExtra("CA3")
        val A3TextView: TextView = findViewById(R.id.A3)
        A3TextView.text = A3

        val HP3 = intent.getStringExtra("CHP3")
        val HP3TextView: TextView = findViewById(R.id.HP3)
        HP3TextView.text = HP3

        val Name4 = intent.getStringExtra("CN4")
        val Name4TextView: TextView = findViewById(R.id.Name4)
        Name4TextView.text = Name4

        val Class4 = intent.getStringExtra("CC4")
        val Class4TextView: TextView = findViewById(R.id.Class4)
        Class4TextView.text = Class4

        val Race4 = intent.getStringExtra("CR4")
        val Race4TextView: TextView = findViewById(R.id.Race4)
        Race4TextView.text = Race4

        val SMod4 = intent.getStringExtra("CSM4")
        val SMod4TextView: TextView = findViewById(R.id.SMod4)
        SMod4TextView.text = SMod4

        val DMod4 = intent.getStringExtra("CDM4")
        val DMod4TextView: TextView = findViewById(R.id.DMod4)
        DMod4TextView.text = DMod4

        val CNMod4 = intent.getStringExtra("CCNM4")
        val CNMod4TextView: TextView = findViewById(R.id.CNMod4)
        CNMod4TextView.text = CNMod4

        val IMod4 = intent.getStringExtra("CIM4")
        val IMod4TextView: TextView = findViewById(R.id.IMod4)
        IMod4TextView.text = IMod4

        val WMod4 = intent.getStringExtra("CWM4")
        val WMod4TextView: TextView = findViewById(R.id.WMod4)
        WMod4TextView.text = WMod4

        val CMMod4 = intent.getStringExtra("CCMM4")
        val CMMod4TextView: TextView = findViewById(R.id.CMMod4)
        CMMod4TextView.text = CMMod4

        val Strength4 = intent.getStringExtra("CS4")
        val Strength4TextView: TextView = findViewById(R.id.Strength4)
        Strength4TextView.text = Strength4

        val Dexerity4 = intent.getStringExtra("CD4")
        val Dexerity4TextView: TextView = findViewById(R.id.Dexerity4)
        Dexerity4TextView.text = Dexerity4

        val Constitution4 = intent.getStringExtra("CCN4")
        val Constitution4TextView: TextView = findViewById(R.id.Constitution4)
        Constitution4TextView.text = Constitution4

        val Intelligence4 = intent.getStringExtra("CI4")
        val Intelligence4TextView: TextView = findViewById(R.id.Intelligence4)
        Intelligence4TextView.text = Intelligence4

        val Wisdom4 = intent.getStringExtra("CW4")
        val Wisdom4TextView: TextView = findViewById(R.id.Wisdom4)
        Wisdom4TextView.text = Wisdom4

        val Charisma4 = intent.getStringExtra("CCM4")
        val Charisma4TextView: TextView = findViewById(R.id.Charisma4)
        Charisma4TextView.text = Charisma4

        val B4 = intent.getStringExtra("CB4")
        val B4TextView: TextView = findViewById(R.id.B4)
        B4TextView.text = B4

        val A4 = intent.getStringExtra("CA4")
        val A4TextView: TextView = findViewById(R.id.A4)
        A4TextView.text = A4

        val HP4 = intent.getStringExtra("CHP4")
        val HP4TextView: TextView = findViewById(R.id.HP4)
        HP4TextView.text = HP4

        val Name5 = intent.getStringExtra("CN5")
        val Name5TextView: TextView = findViewById(R.id.Name5)
        Name5TextView.text = Name5

        val Class5 = intent.getStringExtra("CC5")
        val Class5TextView: TextView = findViewById(R.id.Class5)
        Class5TextView.text = Class5

        val Race5 = intent.getStringExtra("CR5")
        val Race5TextView: TextView = findViewById(R.id.Race5)
        Race5TextView.text = Race5

        val SMod5 = intent.getStringExtra("CSM5")
        val SMod5TextView: TextView = findViewById(R.id.SMod5)
        SMod5TextView.text = SMod5

        val DMod5 = intent.getStringExtra("CDM5")
        val DMod5TextView: TextView = findViewById(R.id.DMod5)
        DMod5TextView.text = DMod5

        val CNMod5 = intent.getStringExtra("CCNM5")
        val CNMod5TextView: TextView = findViewById(R.id.CNMod5)
        CNMod5TextView.text = CNMod5

        val IMod5 = intent.getStringExtra("CIM5")
        val IMod5TextView: TextView = findViewById(R.id.IMod5)
        IMod5TextView.text = IMod5

        val WMod5 = intent.getStringExtra("CWM5")
        val WMod5TextView: TextView = findViewById(R.id.WMod5)
        WMod5TextView.text = WMod5

        val CMMod5 = intent.getStringExtra("CCMM5")
        val CMMod5TextView: TextView = findViewById(R.id.CMMod5)
        CMMod5TextView.text = CMMod5

        val Strength5 = intent.getStringExtra("CS5")
        val Strength5TextView: TextView = findViewById(R.id.Strength5)
        Strength5TextView.text = Strength5

        val Dexerity5 = intent.getStringExtra("CD5")
        val Dexerity5TextView: TextView = findViewById(R.id.Dexerity5)
        Dexerity5TextView.text = Dexerity5

        val Constitution5 = intent.getStringExtra("CCN5")
        val Constitution5TextView: TextView = findViewById(R.id.Constitution5)
        Constitution5TextView.text = Constitution5

        val Intelligence5 = intent.getStringExtra("CI5")
        val Intelligence5TextView: TextView = findViewById(R.id.Intelligence5)
        Intelligence5TextView.text = Intelligence5

        val Wisdom5 = intent.getStringExtra("CW5")
        val Wisdom5TextView: TextView = findViewById(R.id.Wisdom5)
        Wisdom5TextView.text = Wisdom5

        val Charisma5 = intent.getStringExtra("CCM5")
        val Charisma5TextView: TextView = findViewById(R.id.Charisma5)
        Charisma5TextView.text = Charisma5

        val B5 = intent.getStringExtra("CB5")
        val B5TextView: TextView = findViewById(R.id.B5)
        B5TextView.text = B5

        val A5 = intent.getStringExtra("CA5")
        val A5TextView: TextView = findViewById(R.id.A5)
        A5TextView.text = A5

        val HP5 = intent.getStringExtra("CHP5")
        val HP5TextView: TextView = findViewById(R.id.HP5)
        HP5TextView.text = HP5

        onClick1()
        onClick2()
/*
saves the champaign
 */
        SaveDC4.setOnClickListener {
            val intent2 = Intent(this@MainActivity28, MainActivity8::class.java)
            val Title1 = Title1TextView.text.toString()
            val S1 = S1TextView.text.toString()
            val Title2 = Title2TextView.text.toString()
            val S2 = S2TextView.text.toString()
            val Title3 = Title3TextView.text.toString()
            val S3 = S3TextView.text.toString()
            val Title4 = Title4TextView.text.toString()
            val S4 = S4TextView.text.toString()
            val Title5 = Title5TextView.text.toString()
            val S5 = S5TextView.text.toString()

            val Time1 = Time1TextView.text.toString()
            val Time2 = Time2TextView.text.toString()

            val DTitle1 = DTitle1TextView.text.toString()
            val DS1 = DS1TextView.text.toString()
            val DTitle2 = DTitle2TextView.text.toString()
            val DS2 = DS2TextView.text.toString()
            val DTitle3 = DTitle3TextView.text.toString()
            val DS3 = DS3TextView.text.toString()
            val DTitle4 = dcTitles4.text.toString()
            val DS4 = DMChampaignNote4.text.toString()
            val DTitle5 = DTitle5TextView.text.toString()
            val DS5 = DS5TextView.text.toString()

            val Name1 = Name1TextView.text.toString()
            val Class1 = Class1TextView.text.toString()
            val Race1 = Race1TextView.text.toString()
            val SMod1 = SMod1TextView.text.toString()
            val DMod1 = DMod1TextView.text.toString()
            val CNMod1 = CNMod1TextView.text.toString()
            val IMod1 = IMod1TextView.text.toString()
            val WMod1 = WMod1TextView.text.toString()
            val CMMod1 = CMMod1TextView.text.toString()
            val Strength1 = Strength1TextView.text.toString()
            val Dexerity1 = Dexerity1TextView.text.toString()
            val Constitution1 = Constitution1TextView.text.toString()
            val Intelligence1 = Intelligence1TextView.text.toString()
            val Wisdom1 = Wisdom1TextView.text.toString()
            val Charisma1 = Charisma1TextView.text.toString()
            val B1 = B1TextView.text.toString()
            val A1 = A1TextView.text.toString()
            val HP1 = HP1TextView.text.toString()

            val Name2 = Name2TextView.text.toString()
            val Class2 = Class2TextView.text.toString()
            val Race2 = Race2TextView.text.toString()
            val SMod2 = SMod2TextView.text.toString()
            val DMod2 = DMod2TextView.text.toString()
            val CNMod2 = CNMod2TextView.text.toString()
            val IMod2 = IMod2TextView.text.toString()
            val WMod2 = WMod2TextView.text.toString()
            val CMMod2 = CMMod2TextView.text.toString()
            val Strength2 = Strength2TextView.text.toString()
            val Dexerity2 = Dexerity2TextView.text.toString()
            val Constitution2 = Constitution2TextView.text.toString()
            val Intelligence2 = Intelligence2TextView.text.toString()
            val Wisdom2 = Wisdom2TextView.text.toString()
            val Charisma2 = Charisma2TextView.text.toString()
            val B2 = B2TextView.text.toString()
            val A2 = A2TextView.text.toString()
            val HP2 = HP2TextView.text.toString()

            val Name3 = Name3TextView.text.toString()
            val Class3 = Class3TextView.text.toString()
            val Race3 = Race3TextView.text.toString()
            val SMod3 = SMod3TextView.text.toString()
            val DMod3 = DMod3TextView.text.toString()
            val CNMod3 = CNMod3TextView.text.toString()
            val IMod3 = IMod3TextView.text.toString()
            val WMod3 = WMod3TextView.text.toString()
            val CMMod3 = CMMod3TextView.text.toString()
            val Strength3 = Strength3TextView.text.toString()
            val Dexerity3 = Dexerity3TextView.text.toString()
            val Constitution3 = Constitution3TextView.text.toString()
            val Intelligence3 = Intelligence3TextView.text.toString()
            val Wisdom3 = Wisdom3TextView.text.toString()
            val Charisma3 = Charisma3TextView.text.toString()
            val B3 = B3TextView.text.toString()
            val A3 = A3TextView.text.toString()
            val HP3 = HP3TextView.text.toString()

            val Name4 = Name4TextView.text.toString()
            val Class4 = Class4TextView.text.toString()
            val Race4 = Race4TextView.text.toString()
            val SMod4 = SMod4TextView.text.toString()
            val DMod4 = DMod4TextView.text.toString()
            val CNMod4 = CNMod4TextView.text.toString()
            val IMod4 = IMod4TextView.text.toString()
            val WMod4 = WMod4TextView.text.toString()
            val CMMod4 = CMMod4TextView.text.toString()
            val Strength4 = Strength4TextView.text.toString()
            val Dexerity4 = Dexerity4TextView.text.toString()
            val Constitution4 = Constitution4TextView.text.toString()
            val Intelligence4 = Intelligence4TextView.text.toString()
            val Wisdom4 = Wisdom4TextView.text.toString()
            val Charisma4 = Charisma4TextView.text.toString()
            val B4 = B4TextView.text.toString()
            val A4 = A4TextView.text.toString()
            val HP4 = HP4TextView.text.toString()

            val Name5 = Name5TextView.text.toString()
            val Class5 = Class5TextView.text.toString()
            val Race5 = Race5TextView.text.toString()
            val SMod5 = SMod5TextView.text.toString()
            val DMod5 = DMod5TextView.text.toString()
            val CNMod5 = CNMod5TextView.text.toString()
            val IMod5 = IMod5TextView.text.toString()
            val WMod5 = WMod5TextView.text.toString()
            val CMMod5 = CMMod5TextView.text.toString()
            val Strength5 = Strength5TextView.text.toString()
            val Dexerity5 = Dexerity5TextView.text.toString()
            val Constitution5 = Constitution5TextView.text.toString()
            val Intelligence5 = Intelligence5TextView.text.toString()
            val Wisdom5 = Wisdom5TextView.text.toString()
            val Charisma5 = Charisma5TextView.text.toString()
            val B5 = B5TextView.text.toString()
            val A5 = A5TextView.text.toString()
            val HP5 = HP5TextView.text.toString()

            intent2.putExtra("DT1", DTitle1)
            intent2.putExtra("DR1", DS1)
            intent2.putExtra("DT2", DTitle2)
            intent2.putExtra("DR2", DS2)
            intent2.putExtra("DT3", DTitle3)
            intent2.putExtra("DR3", DS3)
            intent2.putExtra("DT4", DTitle4)
            intent2.putExtra("DR4", DS4)
            intent2.putExtra("DT5", DTitle5)
            intent2.putExtra("DR5", DS5)

            intent2.putExtra("TI1", Time1)
            intent2.putExtra("TI2", Time2)

            intent2.putExtra("T1", Title1)
            intent2.putExtra("R1", S1)
            intent2.putExtra("T2", Title2)
            intent2.putExtra("R2", S2)
            intent2.putExtra("T3", Title3)
            intent2.putExtra("R3", S3)
            intent2.putExtra("T4", Title4)
            intent2.putExtra("R4", S4)
            intent2.putExtra("T5", Title5)
            intent2.putExtra("R5", S5)

            intent2.putExtra("CN1", Name1)
            intent2.putExtra("CC1", Class1)
            intent2.putExtra("CR1", Race1)
            intent2.putExtra("CSM1", SMod1)
            intent2.putExtra("CDM1", DMod1)
            intent2.putExtra("CCNM1", CNMod1)
            intent2.putExtra("CIM1", IMod1)
            intent2.putExtra("CWM1", WMod1)
            intent2.putExtra("CCMM1", CMMod1)
            intent2.putExtra("CS1", Strength1)
            intent2.putExtra("CD1", Dexerity1)
            intent2.putExtra("CCN1", Constitution1)
            intent2.putExtra("CI1", Intelligence1)
            intent2.putExtra("CW1", Wisdom1)
            intent2.putExtra("CCM1", Charisma1)
            intent2.putExtra("CCM1", B1)
            intent2.putExtra("CB1", B1)
            intent2.putExtra("CA1", A1)
            intent2.putExtra("CHP1", HP1)

            intent2.putExtra("CN2", Name2)
            intent2.putExtra("CC2", Class2)
            intent2.putExtra("CR2", Race2)
            intent2.putExtra("CSM2", SMod2)
            intent2.putExtra("CDM2", DMod2)
            intent2.putExtra("CCNM2", CNMod2)
            intent2.putExtra("CIM2", IMod2)
            intent2.putExtra("CWM2", WMod2)
            intent2.putExtra("CCMM2", CMMod2)
            intent2.putExtra("CS2", Strength2)
            intent2.putExtra("CD2", Dexerity2)
            intent2.putExtra("CCN2", Constitution2)
            intent2.putExtra("CI2", Intelligence2)
            intent2.putExtra("CW2", Wisdom2)
            intent2.putExtra("CCM2", Charisma2)
            intent2.putExtra("CB2", B2)
            intent2.putExtra("CA2", A2)
            intent2.putExtra("CHP2", HP2)

            intent2.putExtra("CN3", Name3)
            intent2.putExtra("CC3", Class3)
            intent2.putExtra("CR3", Race3)
            intent2.putExtra("CSM3", SMod3)
            intent2.putExtra("CDM3", DMod3)
            intent2.putExtra("CCNM3", CNMod3)
            intent2.putExtra("CIM3", IMod3)
            intent2.putExtra("CWM3", WMod3)
            intent2.putExtra("CCMM3", CMMod3)
            intent2.putExtra("CS3", Strength3)
            intent2.putExtra("CD3", Dexerity3)
            intent2.putExtra("CCN3", Constitution3)
            intent2.putExtra("CI3", Intelligence3)
            intent2.putExtra("CW3", Wisdom3)
            intent2.putExtra("CCM3", Charisma3)
            intent2.putExtra("CB3", B3)
            intent2.putExtra("CA3", A3)
            intent2.putExtra("CHP3", HP3)

            intent2.putExtra("CN4", Name4)
            intent2.putExtra("CC4", Class4)
            intent2.putExtra("CR4", Race4)
            intent2.putExtra("CSM4", SMod4)
            intent2.putExtra("CDM4", DMod4)
            intent2.putExtra("CCNM4", CNMod4)
            intent2.putExtra("CIM4", IMod4)
            intent2.putExtra("CWM4", WMod4)
            intent2.putExtra("CCMM4", CMMod4)
            intent2.putExtra("CS4", Strength4)
            intent2.putExtra("CD4", Dexerity4)
            intent2.putExtra("CCN4", Constitution4)
            intent2.putExtra("CI4", Intelligence4)
            intent2.putExtra("CW4", Wisdom4)
            intent2.putExtra("CCM4", Charisma4)
            intent2.putExtra("CB4", B4)
            intent2.putExtra("CA4", A4)
            intent2.putExtra("CHP4", HP4)

            intent2.putExtra("CN5", Name5)
            intent2.putExtra("CC5", Class5)
            intent2.putExtra("CR5", Race5)
            intent2.putExtra("CSM5", SMod5)
            intent2.putExtra("CDM5", DMod5)
            intent2.putExtra("CCNM5", CNMod5)
            intent2.putExtra("CIM5", IMod5)
            intent2.putExtra("CWM5", WMod5)
            intent2.putExtra("CCMM5", CMMod5)
            intent2.putExtra("CS5", Strength5)
            intent2.putExtra("CD5", Dexerity5)
            intent2.putExtra("CCN5", Constitution5)
            intent2.putExtra("CI5", Intelligence5)
            intent2.putExtra("CW5", Wisdom5)
            intent2.putExtra("CCM5", Charisma5)
            intent2.putExtra("CB5", B5)
            intent2.putExtra("CA5", A5)
            intent2.putExtra("CHP5", HP5)

            startActivity(intent2)
        }
    }
/*
function for timers
 */
    private fun onClick1() {
        val HL = T1.text.toString()
        var counter1 = HL
        object : CountDownTimer(600000, 100000) {
            override fun onTick(millisUntilFinished: Long) {
                T1.setText(String.valueOf(counter1))


            }

            override fun onFinish() {
                T1.setText("FINISH!!")
            }
        }.start()
    }

    private fun onClick2() {
        val BT = T2.text.toString()
        var counter2 = BT
        object : CountDownTimer(600000, 100000) {
            override fun onTick(millisUntilFinished: Long) {
                T2.setText(String.valueOf(counter2))


            }

            override fun onFinish() {
                T2.setText("FINISH!!")
            }
        }.start()
    }
}
