package com.example.characterlogger

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.CountDownTimer
import android.widget.TextView
import kotlinx.android.synthetic.main.activity_main13.*
import kotlinx.android.synthetic.main.activity_main13.T1
import kotlinx.android.synthetic.main.activity_main13.T2
import kotlinx.android.synthetic.main.activity_main23.*
import java.lang.String
/*
code for the first dungeon champaign
 */
class MainActivity23 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main23)
/*
variables for inputs
 */
        val Title1 = intent.getStringExtra("T1")
        val Title1TextView: TextView = findViewById(R.id.ctitles1)
        Title1TextView.text = Title1

        val S1 = intent.getStringExtra("R1")
        val S1TextView: TextView = findViewById(R.id.S1)
        S1TextView.text = S1

        val Title2 = intent.getStringExtra("T2")
        val Title2TextView: TextView = findViewById(R.id.ctitles2)
        Title2TextView.text = Title2

        val S2 = intent.getStringExtra("R2")
        val S2TextView: TextView = findViewById(R.id.S2)
        S2TextView.text = S2

        val Title3 = intent.getStringExtra("T3")
        val Title3TextView: TextView = findViewById(R.id.ctitles3)
        Title3TextView.text = Title3

        val S3 = intent.getStringExtra("R3")
        val S3TextView: TextView = findViewById(R.id.S3)
        S3TextView.text = S3

        val Title4 = intent.getStringExtra("T4")
        val Title4TextView: TextView = findViewById(R.id.ctitles4)
        Title4TextView.text = Title4

        val S4 = intent.getStringExtra("R4")
        val S4TextView: TextView = findViewById(R.id.S4)
        S4TextView.text = S4

        val Title5 = intent.getStringExtra("T5")
        val Title5TextView: TextView = findViewById(R.id.ctitles5)
        Title5TextView.text = Title5

        val S5 = intent.getStringExtra("R5")
        val S5TextView: TextView = findViewById(R.id.S5)
        S5TextView.text = S5

        val Time1 = intent.getStringExtra("TI1")
        val Time1TextView: TextView = findViewById(R.id.T1)
        Time1TextView.text = Time1

        val Time2 = intent.getStringExtra("TI2")
        val Time2TextView: TextView = findViewById(R.id.T2)
        Time2TextView.text = Time2

        val DTitle1 = intent.getStringExtra("DT1")
        val DTitle1TextView: TextView = findViewById(R.id.received_dmchampaigns1)
        DTitle1TextView.text = DTitle1

        val DS1 = intent.getStringExtra("DR1")
        val DS1TextView: TextView = findViewById(R.id.DS1)
        DS1TextView.text = DS1

        val DTitle2 = intent.getStringExtra("DT2")
        val DTitle2TextView: TextView = findViewById(R.id.dctitles2)
        DTitle2TextView.text = DTitle2

        val DS2 = intent.getStringExtra("DR2")
        val DS2TextView: TextView = findViewById(R.id.DS2)
        DS2TextView.text = DS2

        val DTitle3 = intent.getStringExtra("DT3")
        val DTitle3TextView: TextView = findViewById(R.id.dctitles3)
        DTitle3TextView.text = DTitle3

        val DS3 = intent.getStringExtra("DR3")
        val DS3TextView: TextView = findViewById(R.id.DS3)
        DS3TextView.text = DS3

        val DTitle4 = intent.getStringExtra("DT4")
        val DTitle4TextView: TextView = findViewById(R.id.dctitles4)
        DTitle4TextView.text = DTitle4

        val DS4 = intent.getStringExtra("DR4")
        val DS4TextView: TextView = findViewById(R.id.DS4)
        DS4TextView.text = DS4

        val DTitle5 = intent.getStringExtra("DT5")
        val DTitle5TextView: TextView = findViewById(R.id.dctitles5)
        DTitle5TextView.text = DTitle5

        val DS5 = intent.getStringExtra("DR5")
        val DS5TextView: TextView = findViewById(R.id.DS5)
        DS5TextView.text = DS5

        onClick1()
        onClick2()
/*
saves the champaign
 */
        DTCSbtn.setOnClickListener {
            val intent2 = Intent(this@MainActivity23, MainActivity8::class.java)
            val Title1 = Title1TextView.text.toString()
            val S1 = S1TextView.text.toString()
            val Title2 = Title2TextView.text.toString()
            val S2 = S2TextView.text.toString()
            val Title3 = Title3TextView.text.toString()
            val S3 = S3TextView.text.toString()
            val Title4 = Title4TextView.text.toString()
            val S4 = S4TextView.text.toString()
            val Title5 = Title5TextView.text.toString()
            val S5 = S5TextView.text.toString()

            val Time1 = Time1TextView.text.toString()
            val Time2 = Time2TextView.text.toString()

            val DTitle1 = DTitle1TextView.text.toString()
            val DS1 = DS1TextView.text.toString()
            val DTitle2 = DTitle2TextView.text.toString()
            val DS2 = DS2TextView.text.toString()
            val DTitle3 = DTitle3TextView.text.toString()
            val DS3 = DS3TextView.text.toString()
            val DTitle4 = DTitle4TextView.text.toString()
            val DS4 = DS4TextView.text.toString()
            val DTitle5 = DTitle5TextView.text.toString()
            val DS5 = DS5TextView.text.toString()

            intent2.putExtra("DT1", DTitle1)
            intent2.putExtra("DR1", DS1)
            intent2.putExtra("DT2", DTitle2)
            intent2.putExtra("DR2", DS2)
            intent2.putExtra("DT3", DTitle3)
            intent2.putExtra("DR3", DS3)
            intent2.putExtra("DT4", DTitle4)
            intent2.putExtra("DR4", DS4)
            intent2.putExtra("DT5", DTitle5)
            intent2.putExtra("DR5", DS5)

            intent2.putExtra("TI1", Time1)
            intent2.putExtra("TI2", Time2)

            intent2.putExtra("T1", Title1)
            intent2.putExtra("R1", S1)
            intent2.putExtra("T2", Title2)
            intent2.putExtra("R2", S2)
            intent2.putExtra("T3", Title3)
            intent2.putExtra("R3", S3)
            intent2.putExtra("T4", Title4)
            intent2.putExtra("R4", S4)
            intent2.putExtra("T5", Title5)
            intent2.putExtra("R5", S5)

            startActivity(intent2)
        }
    }
/*
function for timers
 */
    private fun onClick1() {
        val HL = T1.text.toString()
        var counter1 = HL
        object : CountDownTimer(600000, 100000) {
            override fun onTick(millisUntilFinished: Long) {
                T1.setText(String.valueOf(counter1))


            }

            override fun onFinish() {
                T1.setText("FINISH!!")
            }
        }.start()
    }

    private fun onClick2() {
        val BT = T2.text.toString()
        var counter2 = BT
        object : CountDownTimer(600000, 100000) {
            override fun onTick(millisUntilFinished: Long) {
                T2.setText(String.valueOf(counter2))


            }

            override fun onFinish() {
                T2.setText("FINISH!!")
            }
        }.start()
    }
}
